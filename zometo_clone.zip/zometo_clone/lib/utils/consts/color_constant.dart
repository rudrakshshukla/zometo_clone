import 'dart:ui';

import 'package:flutter/material.dart';

const Color primaryColor = Color(0xff27DD93);

